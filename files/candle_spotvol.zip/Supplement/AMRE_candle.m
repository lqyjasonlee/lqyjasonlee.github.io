function est = AMRE_candle(RCD,p,type)
%==========================================================================================
%The function calculates the AMRE volatility estimator from k candlestick
%features based on Proposition 1 of BLLL (2024)
%
%INPUT:
%   RCD: k-by-3 matrix of candlestick features in the format of [R C D],
%         where R is the range, C is the absolute return, D is the
%         asymmetry measure. See CHL2RCD.m function for details
%   p: estimat for the p-th power of the spot volatility. Default: p=1
%   type: 's' (default) for the AMRE estimator under the Stein's loss; 'q' for the
%          AMRE estimator under the Quadratic loss.
%
%OUTPUT:
%    est: scalar value of the AMRE estimator
%==========================================================================================
% This ver: 2024/10/28
% Authors: Tim Bollerslev (boller@duke.edu)
%          Jia Li (jiali@smu.edu.sg)
%          Qiyuan Li (qiyuanli@hku.hk)
%          Yifan Li (yifan.li@manchester.ac.uk)
% Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
% Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
%==========================================================================================

if nargin<2
    p = 1;
elseif nargin<3
    type = 's';
end

%calculate the OK estimator for data scaling
lambda1 = sqrt(pi/2) / (8*log(2) - 4);
lambda2 = (4*log(2)-3)/(4*log(2)-2)*sqrt(pi/2);
OK_vol = lambda1*mean(RCD(:,1)) + lambda2*mean(RCD(:,2));
%scale the data for numerical stability
RCD = RCD/OK_vol;

%construct the AMRE estimators according to Proposition 1 of BLLL (2024)
% and rescale the estimators
if type == 's'
    M_k0 = Mkp(RCD,0);
    M_kp = Mkp(RCD,p);
    est = M_k0/M_kp*OK_vol.^p;
elseif type == 'q'
    M_kp = Mkp(RCD,p);
    M_k2p = Mkp(RCD,2*p);
    est = M_kp/M_k2p*OK_vol.^p;
else
    error('Unknown type of estimator')
end
end