# ==========================================================================================
# The python file contains all functions needed to compute optimal range-based estimators.
# ==========================================================================================
# This ver: 2024/10/28
# Authors: Tim Bollerslev (boller@duke.edu)
#          Jia Li (jiali@smu.edu.sg)
#          Qiyuan Li (qiyuanli@hku.hk)
#          Yifan Li (yifan.li@manchester.ac.uk)
# Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
# Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
# ==========================================================================================


import numpy as np
from scipy.stats import norm
from scipy.integrate import quad


def optimal_est(pdata, p=1, bound=6, n_min=1):
    """ AMRE estimators.

    :param pdata: <array_like> k-by-4 data with [open high low close] in each row.
    :param p (optional): <int> estimand is p-th power of spot volatility, default value is 1.
    :param bound (optional): <float> integration bound, default value is 6.
    :param n_min (optional): <float> length of interval measured in minutes, default value is 1.
    :return: <tuple> with (Stein AMRE, Quadratic AMRE).
    """
    k = np.shape(pdata)[0]
    scale = ok_est(pdata, n_min)
    pdata = np.column_stack((pdata[:, 3] - pdata[:, 0],
                             pdata[:, 1] - pdata[:, 0],
                             pdata[:, 2] - pdata[:, 0]))  # return, high, low
    deltan = n_min / (6.5 * 60)  # daily volatility
    pdata = pdata / np.sqrt(deltan)
    data = np.column_stack((pdata[:, 1] - pdata[:, 2],
                            np.abs(pdata[:, 0]),
                            np.abs(pdata[:, 1] + pdata[:, 2] - pdata[:, 0])))  # w, r, a
    data = data / scale
    numer, _ = quad(lambda v: rca_pdf_v2(v, data, k, 0), 0, bound)
    denom, _ = quad(lambda v: rca_pdf_v2(v, data, k, p), 0, bound)
    ret_stein = numer / denom * scale ** p
    denom2, _ = quad(lambda v: rca_pdf_v2(v, data, k, 2 * p), 0, bound)
    ret_quad = denom / denom2 * scale ** p
    return ret_stein, ret_quad


def ok_est(pdata, n_min=1):
    """ BLUE.

    :param pdata: <array_like> k-by-4 data with [open high low close] in each row.
    :param n_min (optional): <float> length of interval measured in minutes, default value is 1.
    :return: <float> best linear unbiased estimates.
    """
    pdata = np.column_stack((pdata[:, 3] - pdata[:, 0],
                             pdata[:, 1] - pdata[:, 0],
                             pdata[:, 2] - pdata[:, 0]))
    deltan = n_min / (6.5 * 60)
    pdata = pdata / np.sqrt(deltan)
    data = np.column_stack((pdata[:, 1] - pdata[:, 2],
                            np.abs(pdata[:, 0]),
                            np.abs(pdata[:, 1] + pdata[:, 2] - pdata[:, 0])))
    a = 1 / (4 * np.log(2) - 2)
    m1 = np.sqrt(2 / np.pi)
    m2 = 2 * m1
    l1 = a / m2
    l2 = (1 - a) / m1
    ret = l1 * np.mean(data[:, 0]) + l2 * np.mean(data[:, 1])
    return ret


def rca_pdf_v2(v, data, k, p, N=100, istrunc=True):
    w = data[:, 0]
    c = data[:, 1]
    d = data[:, 2]
    ret = v ** (3 * k + p - 1)
    for i in range(k):
        if istrunc:
            trunc = 7.3 / (w[i] * 2 * N)  # scale truncation level for robustness
        else:
            trunc = 0
        ret = ret * rcd_pdf(w[i] * v, c[i] * v, d[i] * v, N) * (v >= trunc)
    return ret


def rcd_pdf(R, C, D, N):
    phi2 = lambda x: (x ** 2 - 1) * norm.pdf(x)
    ret = np.zeros_like(R)
    for k in range(1, N + 1):
        ret += 1 * k ** 2 * phi2(2 * k * R + C) \
               - 1 * k * (k + 1) * phi2((2 * k + 1) * R - D) \
               + 1 * k ** 2 * phi2(2 * k * R - C) \
               - 1 * k * (k - 1) * phi2((-2 * k + 1) * R - D)
    return ret