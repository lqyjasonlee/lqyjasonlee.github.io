function RCD = CHL2RCD(CHL)
%==========================================================================================
%The function converts the standard candlestick features (C,H,L) into the
%alternative representation (R,|C|,D), where R = H-L and D = |H-C+L|.
%
%INPUT:
%   CHL: k-by-3 matrix of candlestick features in the format of [C H L],
%         where C is the return, H is the high price and L is the low
%         price with the starting price normalized at 0.
%
%OUTPUT:
%    ret: k-by-3 matrix in the format of [R |C| D]
%==========================================================================================
% This ver: 2024/10/28
% Authors: Tim Bollerslev (boller@duke.edu)
%          Jia Li (jiali@smu.edu.sg)
%          Qiyuan Li (qiyuanli@hku.hk)
%          Yifan Li (yifan.li@manchester.ac.uk)
% Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
% Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
%==========================================================================================



RCD = zeros(size(CHL));
C = CHL(:,1);
H = CHL(:,2);
L = CHL(:,3);

RCD(:,1) = H-L;
RCD(:,2) = abs(C);
RCD(:,3) = abs(H-C+L);

end