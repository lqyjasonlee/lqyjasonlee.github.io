function ret = Mkp(RCD,p)
%==========================================================================================
%The function computes the P M_{k,p} function according to (2.5) of BLLL
%(2024) using numerical integration
%
%INPUT:
%   RCD: k-by-3 matrix of candlestick features in the format of [R C D],
%         where R is the range, C is the absolute return, D is the
%         asymmetry measure. See CHL2RCD.m function for details
%   p: power for the M_{k,p} function to be evaluated
%
%OUTPUT:
%    ret: scalar output of the value of M_{k,p}
%==========================================================================================
% This ver: 2024/10/28
% Authors: Tim Bollerslev (boller@duke.edu)
%          Jia Li (jiali@smu.edu.sg)
%          Qiyuan Li (qiyuanli@hku.hk)
%          Yifan Li (yifan.li@manchester.ac.uk)
% Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
% Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
%==========================================================================================
[k,~] = size(RCD); 
ret = integral(@(w)  Mkp_integrand(w,RCD,k,p),0,6);
end

function ret = Mkp_integrand(v,RCD,k,p)
%helper function that calculates the integrand of the Mkp function
N = 100; %truncate the sums to 100 terms.
w = RCD(:,1);
c = RCD(:,2);
d = RCD(:,3);
ret = v.^(3*k+p-1);
for i = 1:k
    %truncate the function near zero for better numerical stability
    Trunc = 7.3/w(i)/2/N; 
    ret = ret.*RCD_pdf(w(i)*v,c(i)*v,d(i)*v,N).*(v>=Trunc);
end
end


function ret = RCD_pdf(R,C,D,N)
%helper function that evaluates the \tilde{g} function in (2.6) of BLLL (2024)
phi2 = @(x) (x.^2-1).*normpdf(x);
ret = zeros(size(R));
for k = 1:N 
    ret = ret + 1*k^2*phi2(2*k*R+C)-1*k*(k+1)*phi2((2*k+1)*R-D)+1*k^2*phi2(2*k*R-C)-1*k*(k-1)*phi2((-2*k+1)*R-D);
end
end