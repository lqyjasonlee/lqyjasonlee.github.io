%==========================================================================================
% This ver: 2024/10/28
% Authors: Tim Bollerslev (boller@duke.edu)
%          Jia Li (jiali@smu.edu.sg)
%          Qiyuan Li (qiyuanli@hku.hk)
%          Yifan Li (yifan.li@manchester.ac.uk)
% Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
% Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
%==========================================================================================

clearvars; clc;
%Simulate k candlesticks from a standard Brownian Motion with 1% volatility
k=5; true_vol = 0.01;
CHL = rand_candle(k)*true_vol;
%convert candlestick features
RCD = CHL2RCD(CHL);
%construct the AMRE estimators
Stein_vol = AMRE_candle(RCD,1,'s');
Stein_var = AMRE_candle(RCD,2,'s');
Quad_vol = AMRE_candle(RCD,1,'q');
Quad_var =AMRE_candle(RCD,2,'q');

%Calculating 95% confidence intervals according to Table 1 of BLLL (2024)
Stein_vol_CI = [0.8014,1.2344].*Stein_vol;
Stein_var_CI = [0.6314,1.5190].*Stein_var;
Quad_vol_CI = [0.8118,1.2499].*Quad_vol;
Quad_var_CI = [0.6600,1.5918].*Quad_var;
%display the results
result = array2table([true_vol Stein_vol Stein_vol_CI;...
    true_vol.^2 Stein_var Stein_var_CI;...
    true_vol Quad_vol Quad_vol_CI;...
    true_vol.^2 Quad_var Quad_var_CI],'VariableNames',...
    {'TrueParm','AMRE_est','CI95_LB','CI95_UB'},'RowNames', ...
    {'Stein_vol','Stein_var','Quad_vol','Quad_var'});
disp(result)





