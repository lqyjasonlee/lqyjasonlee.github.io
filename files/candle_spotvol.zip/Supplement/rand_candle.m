function ret = rand_candle(N)
%==========================================================================================
% The function simulates N independent candlestick features [C, H, L] from 
% its exact joint distribution according to Proposition 2 of BLLL (2024).
%
%INPUT:
%   N: number of Monte Carlo draws
%
%OUTPUT:
%    ret: N-by-3 matrix of simulated candlestick features [C, H, L]
%==========================================================================================
% This ver: 2024/10/28
% Authors: Tim Bollerslev (boller@duke.edu)
%          Jia Li (jiali@smu.edu.sg)
%          Qiyuan Li (qiyuanli@hku.hk)
%          Yifan Li (yifan.li@manchester.ac.uk)
% Reference: Bollerslev, Li, Li and Li (2024). Optimal Candlestick-Based 
% Spot Volatility Estimation: New Tricks and Feasible Inference Procedures
%==========================================================================================


C = zeros(N,1); H = zeros(N,1); L = zeros(N,1);
%options for fsolve
options = optimoptions('fsolve','SpecifyObjectiveGradient',true,'MaxIterations',1000,'Display','off');

for i = 1:N %can be parallalized using parfor loops
    %sequentially draw from the exact density
    Ctemp = randn(1);
    Utemp = rand(1);U2temp = rand(1);
    Htemp = H_inv(Utemp,Ctemp);
    Ltemp = Inf; tol = 1;trial =0; Ltempd = 0;
    %grid search to compute an initial value for fsolve
    x_grid = linspace(-H_inv(max(U2temp,1-U2temp),abs(Ctemp))*2.5,min(Ctemp,0),120)';
    y_grid = L_cdf( x_grid,Ctemp,Htemp,U2temp);
    y0 = find(diff(y_grid<0)==-1);
    x0_int = [x_grid(y0(1)) x_grid(y0(1)+1)];
    %solve iteratively with randomized initial value to ensure convergence
    while (Ltemp > min(Ctemp,0) || abs(tol) > 1e-6 || Ltempd<=0) && trial <=5
        Ltemp =  fsolve(@(x) L_cdf(x,Ctemp,Htemp,U2temp),unifrnd(x0_int(1),x0_int(2)), options);
        [tol, Ltempd] = L_cdf(Ltemp,Ctemp,Htemp,U2temp);
        trial = trial +1;
    end
    C(i) = Ctemp;
    H(i) = Htemp;
    L(i) = Ltemp;
end
ret = [ C H L];
end

%helper function: the conditional CDF and PDF of L given C and H
function [l_cdf,l_pdf] = L_cdf(l,c,h,p)

phi1=@(x) - x.*normpdf(x);
phi2=@(x) (x.^2-1).*normpdf(x);

kmax = 30; %truncation of the infinite series
l_cdf = zeros(size(l)); 
l_pdf = zeros(size(l)); 

for k=-kmax:kmax
    l_pdf = l_pdf + 2*k^2*phi2(c-2*k*h+2*k*l)-2*k*(k+1)*phi2(c-2*(k+1)*h+2*k*l);
    l_cdf = l_cdf + k*phi1(c-2*k*h+2*k*l)-(k+1)*phi1(c-2*(k+1)*h+2*k*l);
end
l_pdf = (l_pdf)./(-phi1(2*h-c));
l_cdf = 1+(l_cdf)./(-phi1(2*h-c))-p;
end

%helper function: inverse of conditional CDF of H given C
function H_prob = H_inv(p,C)

    H_prob = 1/2*(C + sqrt(C.^2 - 2*log(1-p)));

end

